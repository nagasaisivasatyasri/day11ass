package satya;
public class Account {
	String aType;
	int accNo;
	 String accHolder;
	Customer q=new Customer();
	void addCustomer()
	{
	System.out.println("Enter Account type");
	String aType=Bank.s.next();
	Bank.s.nextLine();
	System.out.println("Enter customer account Number ");
	int accNo=Bank.s.nextInt();
	System.out.println("Enter account holder");
	String accHolder=Bank.s.next();
	Bank.s.nextLine();
	System.out.println("Enter branch  name:");
	String bname=Bank.s.next();
	Customer.add(aType,accNo,accHolder,bname);
}
	void deleteCustomer()
	{
		int x=Bank.s.nextInt();
		Customer.del(x);
	}
 void editCustomer()
	{
	 System.out.println("Enter acc Number to edit");
	 int d=Bank.s.nextInt();
		Customer.edit(d);
		
	}
 void selectCustomer()
 {
	 System.out.println("Enter accNumber");
	 int o=Bank.s.nextInt();
	 q.select(o);
 }
	public Account(String aType, int accNo, String accHolder) {
		this.aType = aType;
		this.accNo = accNo;
		this.accHolder = accHolder;
	}
	public Account() {}


}
